#pragma once

namespace thread
{
	void features();
	void set_settings(bool Fov, bool Cav, bool Outline, bool Damage);
	extern bool can_draw;
}