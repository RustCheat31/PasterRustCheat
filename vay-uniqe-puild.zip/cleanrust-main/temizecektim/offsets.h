#include <cstdint>
inline uintptr_t game_assembly, unity_player, camera_instance;
inline uintptr_t base_networkable, local_player, local_pos_component;

#define gom 0X17C1F18
#define networkable 0x31C07A8
#define oRecoilMinYaw 0x18 //public float recoilYawMin;
#define oRecoilMaxYaw 0x1C //public float recoilYawMax;
#define oRecoilMinPitch 0x20 //public float recoilPitchMin;
#define oRecoilMaxPitch 0x24 //public float recoilPitchMax;

